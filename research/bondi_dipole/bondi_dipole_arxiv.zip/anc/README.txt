Supplemental movies for "Bondi dipole runaway" (N. M. Shirokov).
All four show the scalar-field activity |phi| in the z=0 plane, one frame
per plotfile at 10 fps, H.264; colour scale fixed per field across each run.

video1_headline.mp4  Video 1  headline mixed pair, d0=10, L=64, 256^3, t<=200
                              (Fig. 3; also at youtu.be/egzPDbz2_B0)
video2_t400.mp4      Video 2  t=400 continuation, 128^3
                              (Fig. 4; also at youtu.be/zZcr2N12aww)
video3_PP.mp4        Video 3  same-sign ++ control, 256^3
                              (Fig. 7; also at youtu.be/jsp-Tv-f68Y)
video4_MM.mp4        Video 4  same-sign -- control, 128^3
                              (Fig. 7; also at youtu.be/_J8jfzUk-m4)
