Supplementary videos for
"Binary Ellis-Bronnikov wormholes in 3+1 numerical relativity: mergers,
fly-bys and gravitational waves", Nikita M. Shirokov and Ilya Nachevsky.

Twelve movies, 1920x1080 H.264, numbered as the paper cites them (Video 1-12).
Playback is real time (ten units of t per second) except Video 2, whose frames
are two units apart and which plays at 2x, as stated on its frames. Every video
stops at the last time its run is reliable. The same movies are on YouTube at
the links below, which the paper's captions also carry.

video01_wormhole_throat_collapses.mp4
  One throat with a pure-quadrupole perturbation: it closes, and a horizon
  forms at t = 33.  Paper: Fig. 4 (top).  https://youtu.be/Cc87mHcBPOA

video02_wormhole_throat_inflates.mp4
  The same throat with an inward radial perturbation: it keeps opening to
  t = 218 and stays anti-trapped.  Paper: Fig. 4 (bottom).
  https://youtu.be/RIQCitu4tSc

video03_headon_collision_makes_black_hole.mp4
  Two throats of opposite sign fall together from rest at d = 8; a common
  horizon forms over the pair at t = 18.  Paper: Fig. 6.
  https://youtu.be/3sx9GHRTYVs

video04_wormhole_flyby_no_merger_mouths_inflate.mp4
  d = 12, p = 0.25: a fly-by. No merger, no horizon, both mouths inflate.
  Paper: Sec. VII A.  https://youtu.be/fh3pU7xCU_I

video05_plunge_merger_no_horizon_yet.mp4
  d = 12, p = 0.60: contact at t = 40, the mouths merge, and no trapped
  surface converges through t = 80.  Paper: Sec. VII A.
  https://youtu.be/-ejFKpetL1Y

video06_hardest_plunge_mouths_inflate.mp4
  d = 12, p = 0.90: the fastest plunge; the mouths inflate on the approach.
  Paper: Sec. VII A.  https://youtu.be/yzvwjC46lJY

video07_spiral_merger_makes_black_hole.mp4
  The off-axis merger (d = 6, p = 0.10), across its restarts, to the black
  hole it settles to.  Paper: Fig. 7.  https://youtu.be/jNnMAXPjyRA

video08_control_two_black_holes_collide_headon.mp4
  Vacuum control of the head-on: two black holes at the same d, without the
  scalar field.  Paper: Fig. 8 caption.  https://youtu.be/aRWvD4W8OOg

video09_control_two_black_holes_fly_apart.mp4
  Vacuum control at p = 0.45: the black holes fly apart.
  Paper: Fig. 8 caption.  https://youtu.be/65_3kw4obvE

video10_control_two_black_holes_merge.mp4
  Vacuum control of the d = 12, p = 0.12 run: plunge, merger, ringdown.
  Paper: Fig. 9 caption.  https://youtu.be/NkcpGiJIxXI

video11_headon_collision_far_zone_waves.mp4
  The head-on of Video 3 in a domain four times wider (L = 512), to t = 250.
  Paper: Fig. 8 caption.  https://youtu.be/vesOxaP5GSg

video12_wormholes_push_apart_mouths_inflate.mp4
  Two like-signed throats released from rest repel, and both mouths inflate.
  Paper: Sec. V C.  https://youtu.be/FnbDs-0n5zw
